package com.onmobile.vol.storefront;

public final class TestTags {

	public static final String UNIT_TESTS = "UNIT_TESTS";

	public static final String POSITIVE_TEST = "POSITIVE_TEST";

	public static final String NEGATIVE_TEST = "NEGATIVE_TEST";

	public static final String DESTRUCTIVE_TEST = "DESTRUCTIVE_TEST";

	public static final String GET_USER_INFO = "GET_USER_INFO";

	public static final String UPDATE_USER_INFO = "UPDATE_USER_INFO";

	public static final String BOOKMARKS_SUITE = "BOOKMARKS_SUITE";

	public static final String ADD_BOOKMARKS = "ADD_BOOKMARKS";

	public static final String GET_BOOKMARKS = "GET_BOOKMARKS";

	public static final String DELETE_BOOKMARKS = "DELETE_BOOKMARKS";

}
